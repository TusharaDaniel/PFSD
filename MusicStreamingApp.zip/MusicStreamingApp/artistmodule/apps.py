from django.apps import AppConfig


class ArtistmoduleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'artistmodule'
